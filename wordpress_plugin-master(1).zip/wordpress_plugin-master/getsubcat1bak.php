<?php

$locus_array = "";
$link_record_num = "";
$link_page_total = ""; 
$link_page_id = ""; 
$pagem_url_cat = "";
$link_page_num = ""; 
$cat_page_num = ""; 
$category_id = ""; 
$lnk_num = "";
if(in_array('mn_local_lnk_num', $_GET) AND $_GET['mn_local_lnk_num']!="changeme"){
$mn_local_lnk_num = $_GET['mn_local_lnk_num'];
}
else
{
$mn_local_lnk_num = "change_me";
}
if(in_array('mn_agent_ID', $_GET) AND $_GET['mn_agent_ID']!="changeme"){
$mn_agent_ID = $_GET['mn_agent_ID'];
}
else
{
$mn_agent_ID = "change_me";
}
if(in_array('mn_agent_url', $_GET) AND $_GET['mn_agent_url']!="changeme"){
$mn_agent_url = $_GET['mn_agent_url'];
}
else
{
$mn_agent_url = "change_me";
}
if(in_array('mn_agent_folder', $_GET) AND $_GET['mn_agent_folder']!="changeme"){
$mn_agent_folder = $_GET['mn_agent_folder'];
}
else
{
$mn_agent_folder = "change_me";
}

$args = array();
if(isset($_GET['regional_num'])){$args['regional_num']=  $_GET['regional_num'];}
if(isset($link_record_num)){$args['link_record_num']=  $link_record_num;}
if(isset($link_page_total)){$args['link_page_total']=  $link_page_total;} 
if(isset($link_page_id)){$args['link_page_id']=  $link_page_id; }
if(isset($pagem_url_cat)){$args['pagem_url_cat']=  $pagem_url_cat;}
if(isset($link_page_num)){$args['link_page_num']=  $link_page_num;} 
if(isset($cat_page_num)){$args['cat_page_num']=  $cat_page_num;} 
if(isset($_GET['q'])){$args['category_id']=  $_GET['q']; }
if(isset($lnk_num)){$args['lnk_num']=  $lnk_num;}
$args['http_host']=   $_SERVER['HTTP_HOST'];


$url = "http://".$mn_agent_url."/".$mn_agent_folder."/mannanetwork-dir/get_category_json.php";
echo '$url = ', $url;
//$url = "http://".$agent_url."/".$agent_folder."/get_category_json.php";
  $ch = curl_init();    // initialize curl handle
		    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		    curl_setopt($ch, CURLOPT_URL, $url); 
		    curl_setopt($ch, CURLOPT_FAILONERROR, 1);          
		    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);    
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1); 
		    curl_setopt($ch, CURLOPT_TIMEOUT, 50); 
		    curl_setopt($ch, CURLOPT_POSTFIELDS, $args); 
		    curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
		//  curl_setopt($ch, CURLOPT_PORT, $port);          

		    $jsonlinkList = curl_exec($ch);
		    $curl_errno = curl_errno($ch);
		    $curl_error = curl_error($ch);
		    if ($curl_errno > 0) {
			    echo "cURL Error ($curl_errno): $curl_error\n";
		    } 
 $jsoncomboList = curl_exec($ch);
 curl_close($handle);



require_once('translations/en.php');


$comboList = json_decode($jsoncomboList, true);

$menu_str = '<form action="'. htmlspecialchars($_SERVER["PHP_SELF"], ENT_QUOTES, "utf-8").'"><select name="subCat1" onchange="updatecategoryButton(this.value), showSubCat2(this.value)">
<option value="">'.WORDING_AJAX_MENU1.'</option> ';
foreach($comboList as $key=>$value){
 if($comboList[$key]['lft']+1 < $comboList[$key]['rgt']){
	$menu_str .= "<option value='y:" . $comboList[$key]['id'] .":".$comboList[$key]['name'] ."'>".$comboList[$key]['name']."</option>";
	}
	else
	{
	$menu_str .= "<option value='n:" . $comboList[$key]['id']  .":".$comboList[$key]['name'] . "'>".$comboList[$key]['name']."</option>";
	}
}

$menu_str .= '</select><br>

</form>';
echo $menu_str;

?>

