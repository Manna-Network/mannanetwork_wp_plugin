# wordpress_plugin
Creates a complete (i.e. with categories and links) web directory on a Wordpress website. Requires registration at an active Manna Network agent website. The registration and installation process enable the site to earn BitcoinSV commissions.
