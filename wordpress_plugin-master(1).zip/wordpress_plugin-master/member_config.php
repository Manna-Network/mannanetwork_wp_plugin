<?php
//All of these settings can be gotten from your agent upline. 
$agent_url = "orlandoreferralgroup.com";
$agent_folder = "bitcoin_ad_agency/mannanetwork-dir";
$registration_folder = "bitcoin_ad_agency/manna-network";//used by the endorsements/add-url.php in the iframe to load agent registration page
$lnk_num = '116'; //this would be your link numbergiven by your agent
?>
