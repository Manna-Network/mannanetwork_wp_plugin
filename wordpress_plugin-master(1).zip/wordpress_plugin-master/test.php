<?php
echo 'hello world';
print_r($_GET);
?>